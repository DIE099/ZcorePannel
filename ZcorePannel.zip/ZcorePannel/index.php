<?php
session_start();
$config_file = 'config.json';
if (!file_exists($config_file)) { header('Location: setup.php'); exit; }
$config = json_decode(file_get_contents($config_file), true);
if (isset($_POST['login'])) {
    $username = $_POST['username'] ?? '';
    $password = $_POST['password'] ?? '';
    if (isset($config['users'][$username]) && password_verify($password, $config['users'][$username]['password'])) {
        $_SESSION['loggedin'] = true;
        $_SESSION['username'] = $username;
        $_SESSION['role'] = $config['users'][$username]['role'];
        if (isset($_POST['remember'])) setcookie('zcore_auth', base64_encode($username), time() + 86400 * 30, '/');
        header('Location: dashboard.php'); exit;
    } else $error = "Invalid credentials!";
}
if (isset($_COOKIE['zcore_auth']) && !isset($_SESSION['loggedin'])) {
    $username = base64_decode($_COOKIE['zcore_auth']);
    if (isset($config['users'][$username])) {
        $_SESSION['loggedin'] = true; $_SESSION['username'] = $username; $_SESSION['role'] = $config['users'][$username]['role'];
        header('Location: dashboard.php'); exit;
    }
}
?><!DOCTYPE html>
<html>
<head><meta charset="UTF-8"><title>ZCore Login</title><link rel="stylesheet" href="assets/css/style.css"></head>
<body class="login-page">
<div class="login-container">
    <div class="login-card">
        <h1>ZCore Panel</h1><p>License Management System</p>
        <?php if(isset($error)) echo '<div class="error">'.$error.'</div>'; ?>
        <form method="POST">
            <input type="text" name="username" placeholder="Username" required>
            <input type="password" name="password" placeholder="Password" required>
            <label><input type="checkbox" name="remember"> Keep me logged in</label>
            <button type="submit">Access Panel</button>
        </form>
        <div class="register-link">Don't have an account? <a href="register.php">Register with code</a></div>
    </div>
</div>
</body>
</html>