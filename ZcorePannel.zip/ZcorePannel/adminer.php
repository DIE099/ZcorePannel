<?php
/**
 * Adminer - Database management tool
 * Version: 4.8.1
 */
function adminer_object() {
    
    class ZCoreAdminer extends Adminer {
        
        function name() {
            return 'ZCore Database Manager';
        }
        
        function credentials() {
            // Railway MySQL ke liye (optional)
            // return array('host', 'user', 'password');
            return array(null, null, null);
        }
        
        function login($login, $password) {
            return true;
        }
        
        function permanentLogin() {
            return false;
        }
        
        function database() {
            return 'railway';  // Railway ka default DB name
        }
    }
    
    return new ZCoreAdminer;
}

// Include original Adminer
if (function_exists('adminer_object')) {
    include './adminer.php';
} else {
    // Fallback - direct download adminer
    $adminer_url = 'https://www.adminer.org/static/download/4.8.1/adminer-4.8.1.php';
    $content = file_get_contents($adminer_url);
    if ($content) {
        eval('?' . '>' . $content);
    } else {
        die('Adminer download failed. Please download manually from https://www.adminer.org');
    }
}
?>